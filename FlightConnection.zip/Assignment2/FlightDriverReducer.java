import java.io.IOException;

import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;
import java.util.*;


public class FlightDriverReducer extends
    Reducer<Text, Text, Text, NullWritable> {
  public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException{
   
 //Create two array lists to store values belong to relation T1 from values belong to relation T2
  	  
  ArrayList<String> T1values= new ArrayList<String>();
  ArrayList<String> T2values = new ArrayList<String>();
  
  // The reducer receives a user id and a set of values with this format: relationName,userid , where the relationName could be T1 or T2
  //Separating T1 values from T2 values and storing  them in T1values and T2values arrays.
  for (Text v: values)
  {
	  //Extracting relationName and userid from values
	  String[] splits = v.toString().split(",");
	  String relationName = splits[0];
	  String b= splits[1];
	 String s=splits[2];
	String vs=splits[3];
	// String vd=splits[4];
	//  String vb=splits[5];
	//  String vn=splits[6];
	//  String vl=splits[7];
	 //String datenew=splits[8];
	  if (relationName.equals("T1"))
		  T1values.add(splits[1]+","+splits[2]+","+splits[3]);
	  else
		  T2values.add(splits[1]+","+splits[2]+","+splits[3]);
  }
 
  
  //Now it is time to combine all T1Values with T2Values
  for (String destination : T1values)
  {
	  String[] splits = destination.toString().split(",");
      int s =Integer.parseInt(splits[1]);
  {
	  for (String origin:T2values)
	  
	  {
		  String[] splits1 = origin.toString().split(",");
		  int d =Integer.parseInt(splits1[1]);
		  
		  
		  if(Math.abs(d-s)>= 100 && Math.abs(d-s)<=800)
  
	  
	
		  /*We want the output to be in the format uid1, uid2, uid3 where uid1 follows uid2 and uid2 follows uid3, so we need to put the join key in the middle
		  * Also there is not need to output a value we can put everything in a key and print it on hdfs. 
		  * Alternatively, you could do  context.write(NullWritable.get(), new Text(uid1+"\t"+key+"\t"+uid2));
		  */
	
		
		//System.out.println(T1values.get(2));
		 context.write(new Text(destination+"\t"+key+"\t"+origin), NullWritable.get());
}}}}}

