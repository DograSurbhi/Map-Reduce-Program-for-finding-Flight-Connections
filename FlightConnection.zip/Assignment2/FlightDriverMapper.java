import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.io.*;

public class FlightDriverMapper extends
    Mapper<LongWritable, Text, Text, Text> {
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
  
	  String line= value.toString();
	  
	  //Split the line by space or tab (\\s+) to get the uid1 and uid2
	 String[] splits = line.split(",");
	 try {
		
	 
	 if (splits.length>=21)
	 {
		 String destination= splits[17];
		 String origin=splits[16];
		 int FlightNum=Integer.parseInt(splits[9]);
	 int deptime=Integer.parseInt(splits[5]);
		 int arrivaltime=Integer.parseInt(splits[7]);
		int year=Integer.parseInt(splits[0]);
				int month=Integer.parseInt(splits[1]);
				int day=Integer.parseInt(splits[2]);
				int date=Integer.parseInt(splits[0]+splits[1]+splits[2]);
		String carrier= splits[8];
		int cancel=Integer.parseInt(splits[21]);
		 
		 if(cancel==0)
		 {
		 //For T1, uid2 is the joinkey, so for T1 emit uid2 as key and uid1+t1 as value
		 context.write(new Text(destination+","+carrier+","+date), new Text("T1"+","+origin+","+arrivaltime+","+FlightNum));
		 
		 //For T2, uid1 is the joinkey, so for T1  emit uid1 as key and uid2+t2 as value
		 context.write(new Text(origin+","+carrier+","+date), new Text("T2"+","+destination+","+deptime+","+FlightNum));
		 }

	 }
	 }
	catch(NumberFormatException e)
	{
	}
	
  }
}
